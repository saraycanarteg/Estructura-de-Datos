#ifndef CONSTANTES_H
#define CONSTANTES_H

namespace Constantes {
    const int CELL_SIZE = 60;
    const int MARGIN = 50;
    const int ANIMATION_DELAY = 300;  
    const int ANIMATION_FREQUENCY = 10;  
}

#endif