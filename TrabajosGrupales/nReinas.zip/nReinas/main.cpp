#include "Juego.h"

int main() {
    Juego juego;
    juego.iniciar();
    juego.mostrarResultado();
    return 0;
}