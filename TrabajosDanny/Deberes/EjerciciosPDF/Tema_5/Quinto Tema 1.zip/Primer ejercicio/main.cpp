#include "AnalizadorComplejidadExp.cpp"

int main() {
    AnalizadorComplejidadExp analizador(10);
    analizador.analizarComplejidad();
    return 0;
}