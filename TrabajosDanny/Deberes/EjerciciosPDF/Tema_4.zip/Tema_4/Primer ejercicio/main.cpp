#include "AnalizadorComplejidad.cpp"

int main() {
    AnalizadorComplejidad analizador(1000);
    analizador.analizarComplejidad();
    return 0;
}