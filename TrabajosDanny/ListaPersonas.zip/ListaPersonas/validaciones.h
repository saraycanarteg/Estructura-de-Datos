#ifndef VALIDACIONES_H
#define VALIDACIONES_H

#include <string>
using namespace std;

bool validarCedula(const string& cedula);
bool validarTexto(const string& texto);

#endif
