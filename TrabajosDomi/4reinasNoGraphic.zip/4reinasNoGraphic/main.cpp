// main.cpp
#include "solucion.h"

int main() {
    ChessBoard board;
    board.solveNQueens(4);
    return 0;
}