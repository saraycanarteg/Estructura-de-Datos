// Tetris Numérico 
// Doménica Villagómez

#include "Tetris.h"

int main() {
    Tetris tetris(15, 10);
    tetris.iniciar();
    return 0;
} 